<nav class="navbar navbar-expand navbar-dark" style="background-color: #00826B;">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">KLINIK {{ env("APP_NAME") }}</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
</--------------------------------------------------------Pendaftaran-----------------------------------------------------------------------------------*/>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Pendaftaran</a>
            </li>
</--------------------------------------------------------Akun-----------------------------------------------------------------------------------*/>
            <li class="nav-item">
                <a class="nav-link" href="#">Akun</a>
            </li>
</--------------------------------------------------------Pasien-----------------------------------------------------------------------------------*/>
            <li class="nav-item">
                <a class="nav-link" href="#">Pasien</a>
            </li>
</--------------------------------------------------------Dokter-----------------------------------------------------------------------------------*/>
            <li class="nav-item">
                <a class="nav-link" href="#">Dokter</a>
            </li>
</--------------------------------------------------------Obat-----------------------------------------------------------------------------------*/>
            <li class="nav-item">
                <a class="nav-link" href="#">Obat</a>
            </li>
</--------------------------------------------------------Poli-----------------------------------------------------------------------------------*/>
            <li class="nav-item">
                <a class="nav-link" href="#">Poli</a>
            </li>
</--------------------------------------------------------Jadwal-----------------------------------------------------------------------------------*/>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Jadwal
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Pagi</a></li>
              <li><a class="dropdown-item" href="#">Malam</a></li>
            </ul>
          </li>
          
        </ul>
        
      </div>
    </div>
  </nav>