<title>Laporan Diagnosa Harian </title>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <form action="/clearlaporan" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger"
                onClick="return confirm('Yakin ingin clear data?')">Clear Laporan</button>
        </form>

        <h1>Laporan Pasien Harian</h1>
        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal Daftar</th>
                        <th>Nama</th>
                        <th>Nomer NIK</th>
                        <th>Tanggal Lahir</th>
                        <th>Kode Pasien</th>
                        <th>Lama/Baru</th>
                        <th>Jenis Kelamin</th>
                        <th>R.Jalan/R.Inap</th>
                        <th>Diagnosa</th>
                        <th>Alamat Rumah</th>
                        <th>No Handphone</th>
                        <th>Status Pendidikan</th>
                        <th>Pekerjaan</th>
                        <th>Gol. Darah</th>
                        <th>Tinggi Badan</th>
                        <th>Berat Badan</th>
                        <th>Lingkar Pinggang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count = $count + 1); ?></td>
                        <td><?php echo e($r->created_at->format('H:i -- d/m/Y')); ?></td>
                        <td><?php echo e($r->pasien->nama); ?></td>
                        <td><?php echo e($r->pasien->nik); ?></td>
                        <td><?php echo e($r->pasien->lahir->format('d/m/Y')); ?></td>
                        <td><?php echo e($r->pasien->kodepasien); ?></td>
                        <td><?php echo e($r->lamabaru == '' ? '-' : $r->lamabaru); ?></td>
                        <td><?php echo e($r->pasien->kelamin); ?></td>
                        <td><?php echo e($r->rawat == '' ? '-' : $r->rawat); ?></td>
                        <td><?php echo e($r->diagnosa); ?></td>
                        <td><?php echo e($r->pasien->alamat); ?></td>
                        <td><?php echo e($r->pasien->telepon); ?></td>
                        <td><?php echo e($r->pasien->pendidikan); ?></td>
                        <td><?php echo e($r->pasien->pekerjaan); ?></td>
                        <td><?php echo e($r->darah== '' ? '-' : $r->darah); ?></td>
                        <td><?php echo e($r->tinggi== '' ? '-' : $r->tinggi); ?> Cm</td>
                        <td><?php echo e($r->berat== '' ? '-' : $r->berat); ?> Kg</td>
                        <td><?php echo e($r->pinggang== '' ? '-' : $r->pinggang); ?> Cm</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    lengthMenu: [
                        [50, 100, 200, -1],
                        ['50', '100', '200', 'All']
                    ],
                    buttons: [{
                            extend: 'excel',
                            text: 'Excel',
                            messageTop: 'Laporan Diagnosa Harian Tanggal'+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'
                            
                        },
                        {
                            extend: 'copy',
                            text: 'Copy Isi',
                            
                        },
                        

                    ],
        
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.laporan-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-99\resources\views/laporan-harian.blade.php ENDPATH**/ ?>