<title>Poli / Spesialis</title>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="container">
        <h1>Pilihan Poli / Spesialis Dokter</h1>
        <br>
        <form action="<?php echo e(route('poli.store')); ?>" method="post">
            <?php echo csrf_field(); ?>

            </--------------------------------------------------------Poli-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Poli / Spesials Baru</label>
                <div class="col-sm-7">
                    <input type="text" class="form-control"
                        placeholder="tuliskan Poli..." value="<?php echo e(old('Poli')); ?>" name="name" 
                        required oninvalid="this.setCustomValidity('Isi, jika ingin menambahkan Poli terbaru')" oninput="setCustomValidity('')">
                    
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus text-white"></i> Tambahkan</button>
                   
                </div>
            </div>
        </form>


        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Pilihan Poli / Spesialis</th>
                        <th>Tools</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($count = $count + 1); ?> </td>
                            <td> <?php echo e($p->name); ?></td>
                            <td> 
                                <a href="<?php echo e(route('poli.edit', $p->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip"
                                    data-bs-original-title="Edit Dokter">
                                    <i class="fas fa-pen text-white"></i>
                                </a>
                                </-------------------------------------------------------- hapus
                                    -----------------------------------------------------------------------------------* />
                                <form action="<?php echo e(route('poli.destroy', $p->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onClick="return confirm('Yakin ingin hapus Poli ini?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div><?php /**PATH C:\xampp\htdocs\klinik-majusejahtera\resources\views/poli-form.blade.php ENDPATH**/ ?>