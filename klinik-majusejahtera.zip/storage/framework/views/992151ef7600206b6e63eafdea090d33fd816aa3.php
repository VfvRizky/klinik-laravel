<title>Dokter : <?php echo e($dokter->nama); ?></title>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="container">
        <h1>Perubahan Data Dokter</h1>
        <br>
        <form action="<?php echo e(route('dokter.update', $dokter->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            </--------------------------------------------------------Nama-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Nama" placeholder="Nama" required="required"
                        value="<?php echo e($dokter->nama); ?>" oninvalid="this.setCustomValidity('Nama tidak boleh kosong')" oninput="setCustomValidity('')">
                </div>
            </div>
            </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Alamat" placeholder="Alamat"
                        value="<?php echo e($dokter->alamat); ?>">
                </div>
            </div>


            </--------------------------------------------------------Spesialis-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Spesialis</label>
                <div class="col-sm-5">
                    <select name="Spesialis" class="form-control" value="<?php echo e($dokter->poli->name ?? "-"); ?>">
                        <option selected value="">pilih poli / spesialis</option>
                        <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>


            </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Telepon</label>
                <div class="col-sm-3">
                    <input type="number" class="form-control" id="notelp" name="Telepon"
                        placeholder="Nomer Telepon (aktif)" value="<?php echo e($dokter->telepon); ?>">
                </div>
            </div>


            </--------------------------------------------------------Jadwal lama-----------------------------------------------------------------------------------* />

            <div class="form group row">
                <label class="col-form-label col-sm-2 pt-0">Jadwal Praktek Lama</label>
                <div class="col-sm-8">
                    <input class="form-control" value="<?php echo e($dokter->jadwal->jadwalpraktek ?? "-"); ?>" readonly>
                </div>
            </div>

        </--------------------------------------------------------Jadwal baru-----------------------------------------------------------------------------------* />
            <div class="form group row">
                <label class="col-form-label col-sm-2 pt-0">Jadwal Praktek Baru</label>
                <div class="col-sm-8">
                    <select name="Jadwal" class="form-control" value="<?php echo e($dokter->jadwal->jadwalpraktek ?? "-"); ?>"
                        required oninvalid="this.setCustomValidity('Pilih Jadwal Praktek')" oninput="setCustomValidity('')">
                        <option selected value="">tentukan jadwal praktek baru...</option>
                        <?php $__currentLoopData = $jadwalvariabel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jadwal->id); ?>"><?php echo e($jadwal->jadwalpraktek); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <br>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Ubah</button>
                    <a href="/dokter" class="btn btn-warning">Batal</a>
                </div>
            </div>
        </form>
    </div>
<?php /**PATH C:\xampp\htdocs\klinik-99\resources\views/dokter-form-edit.blade.php ENDPATH**/ ?>