
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Laporan Pasien Harian</h1>
        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal Daftar</th>
                        <th>Nomer Antrian</th>
                        <th>Nama</th>
                        <th>Nomer NIK</th>
                        <th>Tanggal Lahir</th>
                        <th>Kode Pasien</th>
                        <th>Lama / Baru</th>
                        <th>Jenis Kelamin</th>
                        <th>R. Jalan / R. Inap</th>
                        <th>Diagnosa</th>
                        <th>Alamat Rumah</th>
                        <th>No Handphone</th>
                        <th>Status Pendidikan</th>
                        <th>Pekerjaan</th>
                        <th>Gol. Darah</th>
                        <th>Tinggi Badan</th>
                        <th>Berat Badan</th>
                        <th>Lingkar Pinggang</th>
                        

                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <button type="submit" class="btn btn-warning col-sm-5">Download (ke excel)dan Ganti Baru</button>
                        <td>1</td>
                        <td>ambli data dari daftar</td>
                        <td>001</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                        <td>ambil data dari diagnosa</td>
                    </tr>
                    
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [18, "asc"]
                    ],
                    lengthMenu: [
                        [50, 100, 200, -1],
                        ['50', '100', '200', 'All']
                    ],
                    // buttons: [{
                    //         extend: 'csv',
                    //         text: 'Export',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'pdf',
                    //         text: 'Pdf',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'print',
                    //         text: 'Print',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },

                    // ],
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-laravel88\resources\views/laporan-harian.blade.php ENDPATH**/ ?>