<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
    </script>
    <title>Dashboard|Rekam Medis Pasien</title>
</head>

<body>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="container">
        <h4>Rekam Medis Pasien atas nama:</h4>
        <h1><?php echo e($pasien->nama); ?></h1>
        <br>
        <form action="<?php echo e(route('pasien.update', $pasien->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            

        </--------------------------------------------------------kodepasien-----------------------------------------------------------------------------------* />
            <div class="form-group row">
          <label class="col-sm-2 col-form-label">Kode Pasien</label>
          <div class="col-sm-5">
            <input type="text" class="form-control" name="Kodepasien" placeholder="Kodepasien" required="required" value="<?php echo e($pasien->kodepasien); ?>"readonly>
          </div>
        </div>
            </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Alamat" placeholder="Alamat"
                        value="<?php echo e($pasien->alamat); ?>"readonly>
                </div>
            </div>


            </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Lahir</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control" name="Lahir"
                        value="<?php echo e($pasien->lahir->format('Y-m-d')); ?>"readonly>

                </div>
            </div>

            </--------------------------------------------------------NIK-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">NIK (Kartu Keluarga)</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control " id="nonik" name="NIK" placeholder="NIK"
                        value="<?php echo e($pasien->nik); ?>"readonly>
                </div>
            </div>


            </--------------------------------------------------------Kelamin-----------------------------------------------------------------------------------* />

            <div class="form-group row">
                <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Kelamin"
                        placeholder="kelamin..." value="<?php echo e($pasien->kelamin); ?>"readonly>
                </div>
            </div>
            <br>

            </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Telepon</label>
                <div class="col-sm-3">
                    <input type="text" class="form-control" id="notelp" name="Telepon"
                        placeholder="Nomer Telepon (aktif)" value="<?php echo e($pasien->telepon); ?>"readonly>
                </div>
            </div>


            </--------------------------------------------------------Agama-----------------------------------------------------------------------------------* />

            <div class="form group row">
                <label class="col-form-label col-sm-2 pt-0">Agama</label>
                <div class="col-sm-3">

                    <input type="text" class="form-control" name="Agama"
                        placeholder="agama..." value="<?php echo e($pasien->agama); ?>"readonly>
                </div>
            </div>
            <br>




            </--------------------------------------------------------Pendidikan-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-form-label col-sm-2 pt-0">Pendidikan</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Pendidikan"
                        placeholder="pendidikan..." value="<?php echo e($pasien->pendidikan); ?>"readonly>
                </div>
            </div>

            </--------------------------------------------------------Pekerjaan-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Pekerjaan</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Pekerjaan"
                        placeholder="Isi '-' jika belum/tidak bekerja " value="<?php echo e($pasien->pekerjaan); ?>"readonly>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                  <a href="#" class="btn btn-primary">Tambah Rekam Medis</a>
                  <button type="#" class="btn btn-warning">Ubah Data Pasien</button>
                    <a href="/pasien" class="btn btn-danger">Kembali</a>
                </div>
            </div>
        </form>
    </div>
    <div class="container">

      <div class="table-responsive">
        <table class="table table-flush" id="products-list">
          <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Tanggal Periksa</th>
                    <th>Layanan</th>
                    <th>Keluhan</th>
                    <th>Dokter</th>
                    <th>Diagnosa</th>
                    <th>Obat</th>
                    <th>Jumlah Obat</th>
                    <th>Keterangan</th>
                    <th>Tools</th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td> 1 </td>
                    <td> 6 Oktober 2022 </td>
                    <td> Asuransi </td>
                    <td> meriang panas dingin </td>
                    <td> Dr. A </td>
                    <td> Flu dmam </td>
                    <td> Parastamol </td>
                    <td> 3 </td>
                    <td> banyak istirahat </td>

                    
                    
                

                        </form>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>
  </div>

    <script>
        function setInputFilter(textbox, inputFilter, errMsg) {
            ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(
                function(event) {
                    textbox.addEventListener(event, function(e) {
                        if (inputFilter(this.value)) {
                            // Accepted value
                            if (["keydown", "mousedown", "focusout"].indexOf(e.type) >= 0) {
                                this.classList.remove("input-error");
                                this.setCustomValidity("");
                            }
                            this.oldValue = this.value;
                            this.oldSelectionStart = this.selectionStart;
                            this.oldSelectionEnd = this.selectionEnd;
                        } else if (this.hasOwnProperty("oldValue")) {
                            // Rejected value - restore the previous one
                            this.classList.add("input-error");
                            this.setCustomValidity(errMsg);
                            this.reportValidity();
                            this.value = this.oldValue;
                            this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
                        } else {
                            // Rejected value - nothing to restore
                            this.value = "";
                        }
                    });
                });
        }

        setInputFilter(document.getElementById("nonik"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
        setInputFilter(document.getElementById("notelp"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\klinik-laravel\resources\views/pasien-rekammedis.blade.php ENDPATH**/ ?>