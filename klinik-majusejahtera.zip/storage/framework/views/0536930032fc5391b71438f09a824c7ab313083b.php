<title>Perubahan Jenis Obat</title>
<?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="container">
        <h1>Ubah Jenis Obat</h1>
        <br>
        <form action="<?php echo e(route('jenis.update', $jenis->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        </--------------------------------------------------------Jenis Obat-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Jenis Obat</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="jenis" placeholder="Jenis obat.." value="<?php echo e($jenis->jenisobat); ?>">
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Ubah</button>
                    <a href="/obat-jenis" class="btn btn-warning">Kembali</a>
                </div>
            </div>
        </form>
    </div>
<?php /**PATH C:\xampp\htdocs\klinik-99\resources\views/jenis-obat-form-update.blade.php ENDPATH**/ ?>