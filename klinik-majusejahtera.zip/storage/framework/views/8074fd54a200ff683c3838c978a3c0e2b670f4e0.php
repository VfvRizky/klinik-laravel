<title>Ubah Poli/Spesialis</title>
<?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="container">
        <h1>Perubahan Poli / Spesialis</h1>
        <br>
        <form action="<?php echo e(route('poli.update', $poli->id)); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>

            </--------------------------------------------------------Poli lama-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Poli / Spesialis Sebelumnya</label>
                <div class="col-sm-7">
                    <input type="text" class="form-control"
                        value="<?php echo e($poli->name); ?>" readonly>
                </div>
            </div>
            </--------------------------------------------------------Poli baru-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Perubahan Poli / Spesialis</label>
                <div class="col-sm-7">
                    <input type="text" class="form-control <?php $__errorArgs = ['Poli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                        placeholder="tuliskan perubahan poli..." value="<?php echo e($poli->name); ?>" required oninvalid="this.setCustomValidity('isi poli terbaru')" oninput="setCustomValidity('')">
                    
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Edit</button>
                    <a href="/poli-form" class="btn btn-warning">Kembali</a>
                </div>
            </div>

        </form>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\klinik-majusejahtera\resources\views/poli-edit-form.blade.php ENDPATH**/ ?>