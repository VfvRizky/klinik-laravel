
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
</script>
<title>Rekam Medis : <?php echo e($pasien->nama); ?></title>

    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <h4>Rekam Medis Pasien atas nama:</h4>
        <h1><?php echo e($pasien->nama); ?></h1>
        <br>

        </--------------------------------------------------------kodepasien-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Kode Pasien</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Kodepasien" placeholder="Kodepasien"
                    required="required" value="<?php echo e($pasien->kodepasien); ?>"readonly>
            </div>
        </div>
        </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Alamat" placeholder="Alamat"
                    value="<?php echo e($pasien->alamat); ?>"readonly>
            </div>
        </div>


        </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Lahir</label>
            <div class="col-sm-5">
                <input type="date" class="form-control" name="Lahir"
                    value="<?php echo e($pasien->lahir->format('Y-m-d')); ?>"readonly>

            </div>
        </div>

        </--------------------------------------------------------NIK-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">NIK (Kartu Keluarga)</label>
            <div class="col-sm-5">
                <input type="text" class="form-control " id="nonik" name="NIK" placeholder="NIK"
                    value="<?php echo e($pasien->nik); ?>"readonly>
            </div>
        </div>


        </--------------------------------------------------------Kelamin-----------------------------------------------------------------------------------* />

        <div class="form-group row">
            <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Kelamin" placeholder="kelamin..."
                    value="<?php echo e($pasien->kelamin); ?>"readonly>
            </div>
        </div>
        <br>

        </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Telepon</label>
            <div class="col-sm-3">
                <input type="text" class="form-control" id="notelp" name="Telepon"
                    placeholder="Nomer Telepon (aktif)" value="<?php echo e($pasien->telepon); ?>"readonly>
            </div>
        </div>


        </--------------------------------------------------------Agama-----------------------------------------------------------------------------------* />

        <div class="form group row">
            <label class="col-form-label col-sm-2 pt-0">Agama</label>
            <div class="col-sm-3">

                <input type="text" class="form-control" name="Agama" placeholder="agama..."
                    value="<?php echo e($pasien->agama); ?>"readonly>
            </div>
        </div>
        <br>




        </--------------------------------------------------------Pendidikan-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-form-label col-sm-2 pt-0">Pendidikan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Pendidikan" placeholder="pendidikan..."
                    value="<?php echo e($pasien->pendidikan); ?>"readonly>
            </div>
        </div>

        </--------------------------------------------------------Pekerjaan-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Pekerjaan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Pekerjaan"
                    placeholder="Isi '-' jika belum/tidak bekerja " value="<?php echo e($pasien->pekerjaan); ?>"readonly>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-10">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#daftarPasien">
                    Tambah Rekam
                </button>
                <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editPasien">
                    Ubah data pasien
                </button>
                <a href="/pasien" class="btn btn-danger">Kembali</a>
            </div>
        </div>
        
    </div>
    <div class="container">

        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal Periksa</th>
                        <th>Layanan</th>
                        <th>Keluhan</th>
                        <th>Dokter</th>
                        <th>Diagnosa</th>
                        <th>Obat</th>
                        <th>Jumlah Obat</th>
                        <th>Keterangan</th>
                        <th>Rawat</th>
                        <th>Golongan Darah</th>
                        <th>Tinggi</th>
                        <th>Berat</th>
                        <th>Lingkar Pinggang</th>
                        <th>Tools</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $count = 0;
                    ?>
                    <?php $__currentLoopData = $rekam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($count = $count + 1); ?></td>
                            <td>
                                <?php
                                    if ($row->updated_at == '') {
                                        echo 'Belum ada pemriksaan';
                                    } else {
                                        echo date_format($row->updated_at, 'd/m/Y');
                                    }
                                ?>
                            </td>
                            <td> <?php echo e($row->layanan ?? "-"); ?> </td>
                            <td> <?php echo e($row->keluhan ?? "-"); ?> </td>
                            <td> <?php echo e($row->dokter->nama ?? "Dokter belum diinput"); ?> </td>
                            <td>
                                <?php
                                    if ($row->diagnosa == '') {
                                        echo 'Belum ada diagnosa';
                                    } else {
                                        echo $row->diagnosa;
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                    if ($row->obat == '') {
                                        echo 'Belum ada obat';
                                    } else {
                                        echo $row->obat->nama;
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                    if ($row->jumlahobat == '') {
                                        echo '-';
                                    } else {
                                        echo $row->jumlahobat;
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                    if ($row->keterangan == '') {
                                        echo '-';
                                    } else {
                                        echo $row->keterangan;
                                    }
                                ?>
                            </td>
                            <td><?php echo e($row->rawat ?? "-"); ?></td>
                            <td><?php echo e($row->darah ?? "-"); ?></td>
                            <td><?php echo e($row->tinggi ?? "-"); ?> Cm</td>
                            <td><?php echo e($row->berat ?? "-"); ?> Kg</td>
                            <td><?php echo e($row->pinggang ?? "-"); ?> Cm</td>


                            </-------------------------------------------------------- edit
                                -----------------------------------------------------------------------------------* />
                            <td class="text-sm">
                                <a href="editrekam/<?php echo e($row->id); ?>" class="btn btn-warning"
                                    data-bs-toggle="tooltip" data-bs-original-title="Edit Pasien">
                                    <i class="fas fa-pen text-white"></i>
                                </a>

                                </-------------------------------------------------------- hapus
                                    -----------------------------------------------------------------------------------* />
                                <form action="<?php echo e(route('rekam.destroy', $row->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onClick="return confirm('Yakin ingin hapus data?')">
                                        <i class="fas fa-trash"></i></button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>


    <!-- Daftar Pasien Modal -->
    <div class="modal fade fixed top-0 left-0 hidden w-full h-full outline-none overflow-x-hidden overflow-y-auto"
        id="daftarPasien" tabindex="-1" aria-labelledby="daftarPasienLabel" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-lg relative w-auto pointer-events-none">
            <div
                class="modal-content border-none shadow-lg relative flex flex-col w-full pointer-events-auto bg-white bg-clip-padding rounded-md outline-none text-current">
                <div
                    class="modal-header flex flex-shrink-0 items-center justify-between p-4 border-b border-gray-200 rounded-t-md">
                    <h5 class="text-xl font-medium leading-normal text-gray-800" id="exampleModalLgLabel">
                        Tambah Data Diagnosa (<?php echo e($pasien->nama); ?>, <?php echo e($pasien->lahir->age); ?> Tahun)
                    </h5>
                    
                    
                </div>
                <form action="/rekam-store" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($pasien->id); ?>" name="idpasien">
                    <div class="modal-body relative p-4">
                        <!--------------------------------------------------------pilih layanan----------------------------------------------------------------------------------- -->
                        <div class="form-group row mt-2">
                            <label class="col-form-label col-sm-2 pt-0">Layanan</label>
                            <div class="col-sm">
                                <select name="layanan" class="form-control "
                                required oninvalid="this.setCustomValidity('Pilih Layanan...')"
                                    oninput="setCustomValidity('')">
                                    <option value="">pilih layanan...</option>
                                    <option value="Umum">Umum</option>
                                    <option value="Asuransi">Asuransi</option>
                                </select>
                            </div>
                        </div>
                        <!--------------------------------------------------------rekam medis----------------------------------------------------------------------------------- -->
                        <div class="form-group row mt-2">
                            <label class="col-sm-2 col-form-label">Keluhan</label>
                            <div class="col-sm">
                                <textarea type="text" name="keluhan" class="form-control" cols="30" rows="5"
                                    placeholder="isi keluhan pasien, dan sudah berapa lama?"
                                    required oninvalid="this.setCustomValidity('Isi keluhan si pasien')"
                                    oninput="setCustomValidity('')"></textarea>
                            </div>
                        </div>

                        <!--------------------------------------------------------pilih dokter----------------------------------------------------------------------------------- -->
                        <div class="form-group row mt-2">
                            <label class="col-form-label col-sm-2 pt-0">Dokter</label>
                            <div class="col-sm">
                                <select name="dokter" class="form-control "
                                required oninvalid="this.setCustomValidity('Pilih Dokter yang memeriksa')"
                                    oninput="setCustomValidity('')">
                                    <option value="">pilih dokter...</option>
                                    <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>">
                                            <?php echo e($row->nama .' |'); ?> <?php echo e($row->jadwal == '' ? 'Belum ada Jadwal' : $row->jadwal->jadwalpraktek); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <!--------------------------------------------------------DIAGNOSA----------------------------------------------------------------------------------- -->
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Diagnosa</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="diagnosa" placeholder="Diagnosa.."
                                     value="<?php echo e(old('diagnosa')); ?>"
                                    required oninvalid="this.setCustomValidity('Diagnosa tidak boleh kosong')"
                                    oninput="setCustomValidity('')">
                            </div>
                        </div>

                        <!--------------------------------------------------------Obat----------------------------------------------------------------------------------- -->
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Obat</label>
                            <div class="col-sm-5">
                                <select name="obat" id="" class="form-control"
                                required oninvalid="this.setCustomValidity('Pilih Obatnya dahulu..')"
                                    oninput="setCustomValidity('')" >
                                    <option value="">Pilih obat yang diberikan..</option>
                                    <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($o->id); ?>">
                                            <?php echo e($o->nama . ' (Sisa stok: ' . $o->stok . ')'); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <!--------------------------------------------------------banyaknya Obat----------------------------------------------------------------------------------- -->
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Jumlah Obat</label>
                            <div class="col-sm-5">
                                <input type="number" class="form-control" name="jumlahobat"
                                    placeholder="Jumlah obat"  value="<?php echo e(old('Nama')); ?>"
                                    required oninvalid="this.setCustomValidity('isi 0 jika tidak diberikan obat')"
                                    oninput="setCustomValidity('')">
                            </div>
                        </div>

                        <!--------------------------------------------------------keterangan----------------------------------------------------------------------------------- -->
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Keterangan</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="keterangan"
                                    placeholder="Keterangan.." value="<?php echo e(old('keterangan')); ?>"
                                    required oninvalid="this.setCustomValidity('Isi - Jika kosong')"
                                    oninput="setCustomValidity('')">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Ubah Pasien Modal -->
    <div class="modal fade fixed top-0 left-0 hidden w-full h-full outline-none overflow-x-hidden overflow-y-auto"
        id="editPasien" tabindex="-1" aria-labelledby="daftarPasienLabel" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-lg relative w-auto pointer-events-none">
            <div
                class="modal-content border-none shadow-lg relative flex flex-col w-full pointer-events-auto bg-white bg-clip-padding rounded-md outline-none text-current">
                <div
                    class="modal-header flex flex-shrink-0 items-center justify-between p-4 border-b border-gray-200 rounded-t-md">
                    <h3 class="text-xl font-medium leading-normal text-gray-800" id="exampleModalLgLabel">
                        Perubahan data Pasien
                    </h3>
                    
                </div>
                <form action="/update-pasien" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($pasien->id); ?>" name="idpasien">
                    <div class="modal-body relative p-4">
                        </--------------------------------------------------------kodepasien-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Kode Pasien</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="Kodepasien"
                                    placeholder="Kodepasien" required="required" value="<?php echo e($pasien->kodepasien); ?>">
                            </div>
                        </div>

                        </--------------------------------------------------------Nama-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Nama</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="Nama" placeholder="Nama"
                                    value="<?php echo e($pasien->nama); ?>">
                            </div>
                        </div>

                        </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Alamat</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="Alamat" placeholder="Alamat"
                                    value="<?php echo e($pasien->alamat); ?>">
                            </div>
                        </div>


                        </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Lahir</label>
                            <div class="col-sm-5">
                                <input type="date" class="form-control" name="Lahir"
                                    value="<?php echo e($pasien->lahir->format('Y-m-d')); ?>">

                            </div>
                        </div>

                        </--------------------------------------------------------NIK-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">NIK (Kartu Keluarga)</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control " id="nonik" name="NIK"
                                    placeholder="NIK" value="<?php echo e($pasien->nik); ?>">
                            </div>
                        </div>


                        </--------------------------------------------------------Kelamin-----------------------------------------------------------------------------------* />

                        <div class="form-group row">
                            <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
                            <div class="col-sm-5">
                                <select name="Kelamin" class="form-control " required
                                    oninvalid="this.setCustomValidity('jenis kelamin tidak boleh kosong')"
                                    oninput="setCustomValidity('')">

                                    <option selected value="">pilih...</option>
                                    <option value="laki-laki" <?php echo e($pasien->kelamin == 'laki-laki' ? 'selected' : ''); ?> >Laki-laki</option>
                                    <option value="perempuan"<?php echo e($pasien->kelamin == 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <br>

                        </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Telepon</label>
                            <div class="col-sm-3">
                                <input type="text" class="form-control" id="notelp" name="Telepon"
                                    placeholder="Nomer Telepon (aktif)" value="<?php echo e($pasien->telepon); ?>">
                            </div>
                        </div>


                        </--------------------------------------------------------Agama-----------------------------------------------------------------------------------* />

                        <div class="form group row">
                            <label class="col-form-label col-sm-2 pt-0">Agama</label>
                            <div class="col-sm-3">
                                <select name="Agama" class="form-control" required
                                oninvalid="this.setCustomValidity('agama tidak boleh kosong')"
                                oninput="setCustomValidity('')">
                                <option selected value="">Pilih agama..</option>
                                <option value="islam" <?php echo e($pasien->agama == 'islam' ? 'selected' : ''); ?>>Islam</option>
                                <option value="protestan" <?php echo e($pasien->agama == 'protestan' ? 'selected' : ''); ?>>Kristen
                                    Protestan
                                </option>
                                <option value="katolik" <?php echo e($pasien->agama == 'katolik' ? 'selected' : ''); ?>>Kristen Katolik
                                </option>
                                <option value="hindu" <?php echo e($pasien->agama == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
                                <option value="buddha" <?php echo e($pasien->agama == 'buddha' ? 'selected' : ''); ?>>Buddha</option>
                                <option value="konghucu" <?php echo e($pasien->agama == 'konghucu' ? 'selected' : ''); ?>>Konghucu
                                </option>
                            </select>
                            </div>
                        </div>
                        <br>




                        </--------------------------------------------------------Pendidikan-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-form-label col-sm-2 pt-0">Pendidikan</label>
                            <div class="col-sm-5">
                                <select name="Pendidikan" class="form-control ">
                                    <option value="-">-</option>
                                    <option value="sltp/sd-smp" <?php echo e($pasien->pendidikan == 'sltp/sd-smp' ? 'selected' : ''); ?>>SLTP / SD-SMP</option>
                                    <option value="slta/sma" <?php echo e($pasien->pendidikan == 'slta/sma' ? 'selected' : ''); ?>>SLTA / SMA</option>
                                    <option value="sarjana" <?php echo e($pasien->pendidikan == 'sarjana' ? 'selected' : ''); ?>>Sarjana</option>
                                </select>
                            </div>
                        </div>

                        </--------------------------------------------------------Pekerjaan-----------------------------------------------------------------------------------* />
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Pekerjaan</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="Pekerjaan"
                                    placeholder="Isi '-' jika belum/tidak bekerja " value="<?php echo e($pasien->pekerjaan); ?>">
                            </div>
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Edit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        function setInputFilter(textbox, inputFilter, errMsg) {
            ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(
                function(event) {
                    textbox.addEventListener(event, function(e) {
                        if (inputFilter(this.value)) {
                            // Accepted value
                            if (["keydown", "mousedown", "focusout"].indexOf(e.type) >= 0) {
                                this.classList.remove("input-error");
                                this.setCustomValidity("");
                            }
                            this.oldValue = this.value;
                            this.oldSelectionStart = this.selectionStart;
                            this.oldSelectionEnd = this.selectionEnd;
                        } else if (this.hasOwnProperty("oldValue")) {
                            // Rejected value - restore the previous one
                            this.classList.add("input-error");
                            this.setCustomValidity(errMsg);
                            this.reportValidity();
                            this.value = this.oldValue;
                            this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
                        } else {
                            // Rejected value - nothing to restore
                            this.value = "";
                        }
                    });
                });
        }

        setInputFilter(document.getElementById("nonik"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
        setInputFilter(document.getElementById("notelp"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\klinik-99\resources\views/pasien-rekammedis.blade.php ENDPATH**/ ?>