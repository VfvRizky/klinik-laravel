
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Akun</h1>
        <br>

        <a href="/tambah-akun" type="button" class="btn btn-success">Tambah Akun</a>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Admin</th>
                        <th>Superadmin</th>
                        <th>Tools</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count = $count + 1); ?></td>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->email); ?></td>
                        <td><?php echo e($u->is_admin == 1 ? 'Yes' : 'No'); ?></td>
                        <td><?php echo e($u->is_superadmin == 1 ? 'Yes' : 'No'); ?></td>
                        <td>  
                            <a href="<?php echo e(route('user.edit', $u->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip"
                                data-bs-original-title="Edit Obat">
                                Edit
                            </a>

                        </-------------------------------------------------------- hapus
                            -----------------------------------------------------------------------------------* />
                            <form action="<?php echo e(route('user.destroy', $u->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="badge bg-danger"
                                onClick="return confirm('Yakin ingin hapus data?')"><i class="fa fa-trash"></i></button>

                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [11, "asc"]
                    ],
                    lengthMenu: [
                        [5, 10, 25, 50, 100, 1000, -1],
                        ['5', '10', '25', '50', '100', '1000', 'All']
                    ],
                    // buttons: [{
                    //         extend: 'csv',
                    //         text: 'Export',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'pdf',
                    //         text: 'Pdf',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'print',
                    //         text: 'Print',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },

                    // ],
                    language: {
                        "searchPlaceholder": "Cari nama obat",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-laravel88\resources\views/user.blade.php ENDPATH**/ ?>