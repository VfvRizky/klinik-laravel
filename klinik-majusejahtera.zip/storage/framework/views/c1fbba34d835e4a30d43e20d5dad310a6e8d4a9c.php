<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset ('css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <title>Dashboard|Edit Pasien</title>
</head>
<body>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  <?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="alert alert-danger" role="alert">
    <?php echo e($item); ?>

  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <?php endif; ?>  
    <div class="container">
      <h1>Perubahan Data Pasien</h1>
        <br>
    <form action="<?php echo e(route('pasien.update', $pasien->id)); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      
</-------------------------------------------------------- Pengisi -----------------------------------------------------------------------------------*/>     
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Pengisi</label>
            <div class="col-sm-1">
                <input class="form-control" name="Kodepasien" placeholder="Staff" type="text" readonly>
            </div>
          </div>
</--------------------------------------------------------Nama-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Nama</label>
          <div class="col-sm-5">
            <input type="text" class="form-control" name="Nama" placeholder="Nama" required="required" value="<?php echo e($pasien->nama); ?>">
          </div>
        </div>
</--------------------------------------------------------Alamat-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Alamat</label>
          <div class="col-sm-5" >
            <input type="text" class="form-control" name ="Alamat" placeholder="Alamat" value="<?php echo e($pasien->alamat); ?>">
          </div>
        </div>
        

    </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------*/>
    <div class="form-group row">
      <label class="col-sm-2 col-form-label">Lahir</label>
      <div class="col-sm-5" >
        <input type="date" class="form-control" name ="Lahir" value="<?php echo e($pasien->lahir->format('Y-m-d')); ?>">
        
      </div>
    </div>

</--------------------------------------------------------NIK-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">NIK (Kartu Keluarga)</label>
          <div class="col-sm-5">
            <input type="text" class="form-control " id="nonik" name ="NIK" placeholder="NIK" value="<?php echo e($pasien->nik); ?>">
          </div>
        </div>

        
    </--------------------------------------------------------Kelamin-----------------------------------------------------------------------------------*/>
    
    <div class="form-group row">
        <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
        <div class="col-sm-5">
                <select name="Kelamin" class="form-control" value="<?php echo e($pasien->kelamin); ?>">
                  <option selected value =""></option>
                  <option value="laki-laki" <?php echo e($pasien->kelamin == 'laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                  <option value="perempuan" <?php echo e($pasien->kelamin == 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
        </div>
    </div>
    <br>
    
        </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Telepon</label>
          <div class="col-sm-3">
            <input type="text" class="form-control" id="notelp" name ="Telepon" placeholder="Nomer Telepon (aktif)" value="<?php echo e($pasien->telepon); ?>">
          </div>
        </div>
        

    </--------------------------------------------------------Agama-----------------------------------------------------------------------------------*/>
    
    <div class="form group row">
        <label class="col-form-label col-sm-2 pt-0">Agama</label>
        <div class="col-sm-3">
          <select name="Agama" class="form-control" value="<?php echo e($pasien->agama); ?>">
            <option selected value =""></option>
              <option value="islam" <?php echo e($pasien->agama == 'islam' ? 'selected' : ''); ?>>Islam</option>
              <option value="protestan" <?php echo e($pasien->agama == 'protestan' ? 'selected' : ''); ?>>Kristen Protestan</option>
              <option value="katolik" <?php echo e($pasien->agama == 'katolik' ? 'selected' : ''); ?>>Kristen Katolik</option>
              <option value="hindu" <?php echo e($pasien->agama == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
              <option value="buddha" <?php echo e($pasien->agama == 'buddha' ? 'selected' : ''); ?>>Buddha</option>
              <option value="konghucu" <?php echo e($pasien->agama == 'konghucu' ? 'selected' : ''); ?>>Konghucu</option>
          </select>
        </div>
      </div>
      <br>
    
    
    
        
    </--------------------------------------------------------Pendidikan-----------------------------------------------------------------------------------*/>
    <div class="form-group row">
      <label class="col-form-label col-sm-2 pt-0">Pendidikan</label>
      <div class="col-sm-5">
              <select name="Pendidikan" class="form-control" value="<?php echo e($pasien->pendidikan); ?>">
                <option value="-">-</option>
                <option value="sltp/sd-smp" <?php echo e($pasien->pendidikan == 'sltp/sd-smp' ? 'selected' : ''); ?>>SLTP / SD-SMP</option>
                <option value="slta/sma" <?php echo e($pasien->pendidikan == 'slta/sma' ? 'selected' : ''); ?>>SLTA / SMA</option>
                <option value="sarjana" <?php echo e($pasien->pendidikan == 'sarjana' ? 'selected' : ''); ?>>Sarjana</option>
              </select>
      </div>
  </div>

</--------------------------------------------------------Pekerjaan-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Pekerjaan</label>
          <div class="col-sm-5">
            <input type="text" class="form-control" name ="Pekerjaan" placeholder="Isi '-' jika belum/tidak bekerja " value="<?php echo e($pasien->pekerjaan); ?>">
          </div>
        </div>

        <div class="form-group row">
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Ubah</button>
            <a href="/pasien" class="btn btn-warning">Batal</a>
          </div>
        </div>
      </form>
    </div>

    <script>
      function setInputFilter(textbox, inputFilter, errMsg) {
["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(function(event) {
  textbox.addEventListener(event, function(e) {
    if (inputFilter(this.value)) {
      // Accepted value
      if (["keydown","mousedown","focusout"].indexOf(e.type) >= 0){
        this.classList.remove("input-error");
        this.setCustomValidity("");
      }
      this.oldValue = this.value;
      this.oldSelectionStart = this.selectionStart;
      this.oldSelectionEnd = this.selectionEnd;
    } else if (this.hasOwnProperty("oldValue")) {
      // Rejected value - restore the previous one
      this.classList.add("input-error");
      this.setCustomValidity(errMsg);
      this.reportValidity();
      this.value = this.oldValue;
      this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
    } else {
      // Rejected value - nothing to restore
      this.value = "";
    }
  });
});
}

      setInputFilter(document.getElementById("nonik"), function(value) {
return /^-?\d*$/.test(value); }, "Isi dengan Angka");
      setInputFilter(document.getElementById("notelp"), function(value) {
return /^-?\d*$/.test(value); }, "Isi dengan Angka");
  </script>

</body>
</html><?php /**PATH C:\xampp\htdocs\klinik-laravel\resources\views/pasien-form-edit.blade.php ENDPATH**/ ?>