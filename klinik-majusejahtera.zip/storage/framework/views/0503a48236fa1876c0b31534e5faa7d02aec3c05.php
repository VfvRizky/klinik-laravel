<title>Ubah Jadwal</title>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  <?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="alert alert-danger" role="alert">
    <?php echo e($item); ?>

  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <?php endif; ?>  
    <div class="container">
      <h1>Perubahan Jadwal</h1>
        <br>
    <form action="<?php echo e(route('jadwal.update', $jadwal->id)); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      

    </--------------------------------------------------------Jadwal lama-----------------------------------------------------------------------------------*/>
    <div class="form-group row">
      <label class="col-sm-2 col-form-label">Jadwal Lama</label>
      <div class="col-sm-5" >
        <input type="text" class="form-control" name ="Jadwal" placeholder="Jadwal" value="<?php echo e($jadwal->jadwalpraktek); ?>" readonly>
      </div>
    </div>

    </--------------------------------------------------------Jadwal baru-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Jadwal Baru</label>
          <div class="col-sm-5" >
            <input type="text" class="form-control" name ="Jadwal" placeholder="Jadwal" value="<?php echo e($jadwal->jadwalpraktek); ?>">
          </div>
        </div>
        


        <div class="form-group row">
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Ubah</button>
            <a href="/jadwal" class="btn btn-warning">Batal</a>
          </div>
        </div>
      </form>
    </div>

<?php /**PATH C:\xampp\htdocs\klinik-majusejahtera\resources\views/jadwal-form-edit.blade.php ENDPATH**/ ?>