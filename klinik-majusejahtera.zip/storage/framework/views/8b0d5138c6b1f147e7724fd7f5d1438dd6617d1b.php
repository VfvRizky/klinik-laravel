
<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Daftar Harian Pasien</h1>
        <br>

        <?php if(session()->has('failed')): ?>
            <div class="alert alert-danger mb-3" role="alert">
                <?php echo e(session('failed')); ?>

            </div>
        <?php elseif(session()->has('addsuccess')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('addsuccess')); ?>

            </div>
        <?php endif; ?>
        

        <a href="/tambahpasienadmin" type="button" class="btn btn-success">
            Tambah Pasien Baru</a>

<section class="mt-4">
        <h4>Pasien Lama</h4>
        <form action="/cekpasienlamaadmin" method="POST">
            <?php echo csrf_field(); ?>
            <!--------------------------------------------------------Nama----------------------------------------------------------------------------------->
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama Lengkap</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Nama" placeholder="Nama Lengkap" required="required"
                        oninvalid="this.setCustomValidity('Nama tidak boleh kosong')" oninput="setCustomValidity('')">
                </div>
            </div>
            </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Lahir</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control <?php $__errorArgs = ['Lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Lahir"
                        placeholder="Lahir">
                    <?php $__errorArgs = ['Lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            "tanggal lahir masih kosong
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-warning col-sm-1">Cari</button>
            </div>
        </form>
    </section>


    <div class="modal fade" id="pasienlamas" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="antrianLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div id="kartuantrian">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">
                            <img src="<?php echo e(asset('img/logo.png')); ?>" style=”float:left;
                                width="55";height="55"” />Klinik Antah
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p class="h3">Data Pasien Ditemukan</p>
                        <p>Nama : <span class="text-primary"><?php echo e(Session::get('nama')); ?></span>
                        </p>
                        <p>Alamat : <span class="text-primary"><?php echo e(Session::get('alamat')); ?></span>
                        </p>
                        <p>Tanggal Lahir : <span class="text-primary"><?php echo e(Session::get('lahir')); ?></span>
                        </p>
                        <p>Kelamin : <span class="text-primary"><?php echo e(Session::get('kelamin')); ?></span>
                        </p>

                        <form action="addrekamadmin" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row mt-2">
                                <input type="text" value="<?php echo e(Session::get('id')); ?>" name="id_player" readonly
                                    hidden>
                            </div>
                            <div class="form-group row mt-2">
                                <label class="col-form-label col-sm-2 pt-0">Layanan</label>
                                <div class="col-sm">
                                    <select name="layanan" class="form-control ">
                                        <option value="-">pilih layanan...</option>
                                        <option value="Umum">Umum</option>
                                        <option value="Asuransi">Asuransi</option>
                                    </select>
                                </div>
                            </div>
                            <!--------------------------------------------------------rekam medis----------------------------------------------------------------------------------- -->
                            <div class="form-group row mt-2">
                                <label class="col-sm-2 col-form-label">Keluhan</label>
                                <div class="col-sm">
                                    
                                    <textarea type="text" name="keluhan" class="form-control" cols="30" rows="5"
                                        placeholder="Jelaskan sakit anda, dan sudah berapa lama?"></textarea>
                                </div>
                            </div>

                            <!--------------------------------------------------------pilih dokter----------------------------------------------------------------------------------- -->
                            <div class="form-group row mt-2">
                                <label class="col-form-label col-sm-2 pt-0">Dokter</label>
                                <div class="col-sm">
                                    <select name="dokter" class="form-control ">
                                        <option value="-">pilih dokter...</option>
                                        <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Tambah Layanan</button>
                    </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>

            <?php if(Session::has('success')): ?>
            $(document).ready(function() {
                $('#pasienlamas').modal('show')
            });
            <?php endif; ?>

            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [11, "asc"]
                    ],
                    lengthMenu: [
                        [5, 10, 25, 50, 100, 1000, -1],
                        ['5', '10', '25', '50', '100', '1000', 'All']
                    ],
                    // buttons: [{
                    //         extend: 'csv',
                    //         text: 'Export',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'pdf',
                    //         text: 'Pdf',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'print',
                    //         text: 'Print',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },

                    // ],
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-laravel\resources\views/pendaftaran.blade.php ENDPATH**/ ?>