<title>Antrian-Pasien (Jam <?php echo e(\Carbon\Carbon::now()->format("H:i")); ?>)</title>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <div class="container">
        <h1>Data Antrian Pasien Harian</h1>
        <br>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tools</th>
                        <th>No Antrian</th>
                        <th>Jam Daftar</th>
                        <th>Nama</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Jenis Layanan</th>
                        <th>Keluhan</th>
                        <th>Dokter</th>

                        <th>Alamat</th>
                        <th>NIK</th>
                        <th>Nomer Telepon</th>
                        <th>Agama</th>
                        <th>Pendidikan</th>
                        <th>Pekerjaan</th>                       
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $count = 0;
                    ?>
                    <?php $__currentLoopData = $datarekam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($count = $count + 1); ?></td>
                            <td><a href="<?php echo e(route('rekam.edit', $row->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip" data-bs-original-title="Lihat Pasien">
                                <i class="fas fa-pen text-white"></i>
                            </a>
                            <form action="<?php echo e(route('rekam.destroy', $row->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger"
                                    onClick="return confirm('Yakin ingin hapus data?')">
                                    <i class="fas fa-trash"></i></button>
                            </form>
                            </td>
                            <td><?php echo e($row->nomorantrian); ?></td>
                            <td><?php echo e($row->updated_at->format('H:i:s -- d/m/Y')); ?></td>   
                            <td><?php echo e($row->pasien->nama); ?></td>
                            <td><?php echo e($row->pasien->lahir->format('d/M/Y')); ?></td>
                            <td><?php echo e($row->pasien->kelamin); ?></td>
                            <td><?php echo e($row->layanan); ?></td>
                            <td><?php echo e($row->keluhan); ?></td>
                            <td><?php echo e($row->dokter->nama ?? "Dokter Tidak ada"); ?></td>
                            <td><?php echo e($row->pasien->alamat); ?></td>
                            <td><?php echo e($row->pasien->nik); ?></td>
                            <td>
                                <a href="https://api.whatsapp.com/send?phone=<?php echo $row->pasien['telepon']; ?>"
                                    target=" _blank" title="Pesan WhatsApp" class="btn btn-success">
                                       <b><?php echo e($row->pasien->telepon); ?></b>
                                   </a>
                                
                               </td>
                            <td><?php echo e($row->pasien->agama); ?></td>
                            <td><?php echo e($row->pasien->pendidikan); ?></td>
                            <td><?php echo e($row->pasien->pekerjaan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    lengthMenu: [
                        [50, 100, 5, -1],
                        ['50', '100', '5', 'All']
                    ],
                    buttons: [{
                            extend: 'excel',
                            text: 'Excel',
                            messageTop: 'Data Antrian Harian per Tanggal '+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'
                            
                        },
                        {
                            extend: 'copy',
                            text: 'Copy Isi',
                            messageTop: 'Data Antrian Harian per Tanggal '+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'
                            
                        },
                    ],
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });

            // <!--------------------------------------------------------auto refresh page----------------------------------------------------------------------------------->
            setTimeout(function() {
                window.location.reload();
            }, 16000);
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-99\resources\views/antrian-pasien-admin.blade.php ENDPATH**/ ?>