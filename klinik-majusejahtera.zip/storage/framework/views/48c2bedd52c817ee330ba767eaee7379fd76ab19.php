<title>Pegawai Baru</title>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e($item); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php endif; ?>
    <div class="container">
        <h1>Pegawai Baru</h1>
        <br>
        <form action="<?php echo e(route('pegawai.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
     
        </--------------------------------------------------------Kode Pegawai-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Kode Pegawai</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="KodePegawai" placeholder="Kode Pegawai..."
                        value="<?php echo e(old('KodePegawai')); ?>"
                        required oninvalid="this.setCustomValidity('Isi - jika tidak ada')" oninput="setCustomValidity('')">
                </div>
            </div>
            </--------------------------------------------------------Nama-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Nama" placeholder="Nama" required="required"
                        value="<?php echo e(old('Nama')); ?>" oninvalid="this.setCustomValidity('Nama tidak boleh kosong')" oninput="setCustomValidity('')">
                </div>
            </div>
            </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Alamat"
                        placeholder="Alamat" value="<?php echo e(old('Alamat')); ?>"
                        required oninvalid="this.setCustomValidity('Isi - jika tidak tau')" oninput="setCustomValidity('')">
                </div>
            </div>


        </--------------------------------------------------------Kelamin-----------------------------------------------------------------------------------*/>
    
        <div class="form-group row">
            <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
            <div class="col-sm-5">
                <select name="Kelamin" value="<?php echo e(old('Kelamin')); ?>" class="form-control"
                required oninvalid="this.setCustomValidity('pilih salah satu...')" oninput="setCustomValidity('')">

                    <option selected value="">pilih...</option>
                    <option value="laki-laki" <?php echo e(old('Kelamin') != 'laki-laki' ?: 'selected'); ?>>Laki-laki</option>
                    <option value="perempuan" <?php echo e(old('Kelamin') != 'perempuan' ?: 'selected'); ?>>Perempuan</option>
                </select>
            </div>
        </div>

            </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Telepon</label>
                <div class="col-sm-3">
                    <input type="number" class="form-control" id="notelp"
                        name="Telepon" placeholder="Nomer Telepon (aktif)" value="<?php echo e(old('Telepon')); ?>"
                        required oninvalid="this.setCustomValidity('Isi 0 jika tidak tau')" oninput="setCustomValidity('')">
                </div>
            </div>


        </--------------------------------------------------------Agama-----------------------------------------------------------------------------------* />

        <div class="form group row">
            <label class="col-form-label col-sm-2 pt-0">Agama</label>
            <div class="col-sm-3">
                <select name="Agama" class="form-control <?php $__errorArgs = ['Agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option selected value=""></option>
                    <option value="islam" <?php echo e(old('Agama') != 'islam' ?: 'selected'); ?>>Islam</option>
                    <option value="protestan" <?php echo e(old('Agama') != 'protestan' ?: 'selected'); ?>>Kristen Protestan</option>
                    <option value="katolik" <?php echo e(old('Agama') != 'katolik' ?: 'selected'); ?>>Kristen Katolik</option>
                    <option value="hindu" <?php echo e(old('Agama') != 'hindu' ?: 'selected'); ?>>Hindu</option>
                    <option value="buddha" <?php echo e(old('Agama') != 'buddha' ?: 'selected'); ?>>Buddha</option>
                    <option value="konghucu" <?php echo e(old('Agama') != 'konghucu' ?: 'selected'); ?>>Konghucu</option>
                </select>
                <?php $__errorArgs = ['Agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        "agama masih kosong
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <br>
    </--------------------------------------------------------Jabatan-----------------------------------------------------------------------------------* />

    <div class="form group row">
        <label class="col-form-label col-sm-2 pt-0">Jabatan</label>
        <div class="col-sm-3">
            <select name="Jabatan" class="form-control" required oninvalid="this.setCustomValidity('pilih jabatan...')"
            oninput="setCustomValidity('')">
                <option selected value="">pilih...</option>
                <option value="-" <?php echo e(old('Jabatan') != '-' ?: 'selected'); ?>>-</option>
                <option value="Perawat" <?php echo e(old('Jabatan') != 'Perawat' ?: 'selected'); ?>>Perawat</option>
                <option value="Apoteker" <?php echo e(old('Jabatan') != 'Apoteker' ?: 'selected'); ?>>Apoteker</option>
                <option value="Admin" <?php echo e(old('Jabatan') != 'Admin' ?: 'selected'); ?>>Admin</option>
                <option value="Bendahara" <?php echo e(old('Jabatan') != 'Bendahara' ?: 'selected'); ?>>Bendahara</option>
                <option value="Security" <?php echo e(old('Jabatan') != 'Security' ?: 'selected'); ?>>Security</option>
                
            </select>
           
        </div>
    </div>
            <br>
            

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Tambah</button>
                    <a href="/pegawai" class="btn btn-warning">Kembali</a>
                </div>
            </div>
        </form>
    </div>
<?php /**PATH C:\xampp\htdocs\klinik-majusejahtera\resources\views/pegawai-form.blade.php ENDPATH**/ ?>