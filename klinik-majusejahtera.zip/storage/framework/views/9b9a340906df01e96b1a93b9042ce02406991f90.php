<title>Pegawai Klinik</title>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Pegawai</h1>
        <br>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <a href="/pegawai/create" type="button" class="btn btn-success">
            <i class="fas fa-plus text-white"></i>Tambah Pegawai</a>
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Kode Pegawai</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Jenis Kelamin</th>
                        <th>Nomer Telepon</th>
                        <th>Agama</th>
                        <th>Jabatan</th>
                        <th>Tools</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $datapegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->iteration); ?> </td>
                            <td> <?php echo e($pg->kodepegawai); ?> </td>
                            <td> <?php echo e($pg->nama); ?> </td>
                            <td> <?php echo e($pg->alamat); ?> </td>
                            <td> <?php echo e($pg->kelamin); ?> </td>
                            <td> 
                                <a href="https://api.whatsapp.com/send?phone=<?php echo $pg['telepon']; ?>"
                                     target=" _blank" title="Pesan WhatsApp" class="btn btn-success">
                                        <b><?php echo e($pg->telepon); ?></b>
                                    </a>

                                 </td>
                            <td> <?php echo e($pg->agama); ?> </td>
                            <td> <?php echo e($pg->jabatan); ?> </td>

                            </-------------------------------------------------------- edit
                                -----------------------------------------------------------------------------------* />
                            <td class="text-sm">
                                <a href="<?php echo e(route('pegawai.edit', $pg->id)); ?>" class="btn btn-warning">
                                    <i class="fas fa-pen text-white"></i>
                                </a>
                                </-------------------------------------------------------- hapus
                                    -----------------------------------------------------------------------------------* />
                                <form action="<?php echo e(route('pegawai.destroy', $pg->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onClick="return confirm('Yakin ingin hapus data?')">
                                        <i class="fas fa-trash"></i></button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#products-list').DataTable({
                dom: 'lBfrtip',
                lengthMenu: [
                    [25, 100, -1],
                    ['25', '100', 'All']
                ],
                buttons: [{
                        extend: 'excel',
                        text: 'Excel',
                        messageTop: 'Data Pegawai Dicetak pada Tanggal '+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'
                    },
                    {
                        extend: 'copy',
                        text: 'Copy Isi',
                        messageTop: 'Data Pegawai di Copy pada Tanggal '+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'                 
                    },
                ],
                language: {
                    "searchPlaceholder": "Cari nama Pegawai",
                    "zeroRecords": "Tidak ditemukan data yang sesuai",
                    "emptyTable": "Tidak terdapat data di tabel"
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-99\resources\views/pegawai.blade.php ENDPATH**/ ?>