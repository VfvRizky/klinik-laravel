
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Diagnosa Pasien Harian</h1>
        <h3>Diagnosa ini akan masuk ke Tabel Rekam medis pasien yang ada didatabase</h3>
        <h5>kode pasien akan terbuat disini "bagi pasien baru,, jika sudah ditambahkan diagnosa</h5>
        <h5>bagi pasien lama, datanya yang masuk hanya tabel rekam medis saja karena kodepasien sudah ada</h5>
        <h5>jadi,, diagnosa ini membuat data pasien beserta data rekam medisnya bagi yang baru</h5>
        <h5>bagi yang lama,, diagnosa sama dengan menambahkan data rekam medisnya saja</h5>
        <br>
        <a href="/diagnosa-form" class="btn btn-warning">contoh formnya</a>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tools</th>
                        <th>Kode Pasien</th>
                        
                        
                        <th>Nama</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Jenis Layanan</th>
                        <th>Keluhan</th>
                        <th>Dokter</th>
                        <th>Diagnosa</th>
                        <th>Obat</th>
                        <th>Jumlah Obat</th>
                        <th>Keterangan</th>

                        <th>Alamat</th>
                        <th>NIK</th>
                        <th>Nomer Telepon</th>
                        <th>Agama</th>
                        <th>Pendidikan</th>
                        <th>Pekerjaan</th>                       
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        <td> 1 </td>
                        <td> button Hapus/Diagnosa/Edit</td>
                                    
                        <td> ini baru, jadi kosong -</td>
                        <td> alfabet</td>
                        <td> 9/9/1999</td>
                        <td> saya netral</td>
                        <td> asuransi</td>
                        <td> meriang panas dingin</td>
                        <td> dr a</td>
                        <td> antah berantah</td>
                        <td> 123456789</td>
                        <td> 0869696969</td>
                        <td> -</td>
                        <td> -</td>
                        <td> -</td>
                        <td> -</td>
                        <td> -</td>
                        <td> -</td>
                        <td> -</td>

                        </tr>

                        <tr>
                            <td> 1 </td>
                            <td> button Hapus/Diagnosa/Edit</td>
                                        
                            <td> ini pasien lama, 0594959</td>
                            <td> lolipop</td>
                            <td> 2/2/2000</td>
                            <td> saya netral</td>
                            <td> umum</td>
                            <td> merianggg</td>
                            <td> dr b</td>
                            <td> antah berantah</td>
                            <td> 123456789</td>
                            <td> 0869696969</td>
                            <td> -</td>
                            <td> -</td>
                            <td> -</td>
                            <td> -</td>
                            <td> -</td>
                            <td> -</td>
                            <td> -</td>
    
                            </tr>
                    
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [11, "asc"]
                    ],
                    lengthMenu: [
                        [5, 10, 25, 50, 100, 1000, -1],
                        ['5', '10', '25', '50', '100', '1000', 'All']
                    ],
                    // buttons: [{
                    //         extend: 'csv',
                    //         text: 'Export',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'pdf',
                    //         text: 'Pdf',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'print',
                    //         text: 'Print',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },

                    // ],
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-laravel\resources\views/diagnosa.blade.php ENDPATH**/ ?>