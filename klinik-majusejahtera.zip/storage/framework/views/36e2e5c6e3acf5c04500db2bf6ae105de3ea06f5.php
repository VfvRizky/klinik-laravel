<title>Pasien Sebelum di Diagnosa</title>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Diagnosa Pasien Harian</h1>
        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Diagnosa</th>
                        <th>Nomer Antrian</th>
                        <th>Kode Pasien</th>
                        <th>Nama</th>
                        <th>Tanggal Lahir</th>
                        <th>Umur</th>
                        <th>Jenis Layanan</th>
                        <th>Keluhan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $count = 0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count=$count+1); ?></td>
                        <td> 
                            <a href="<?php echo e(route('diagnosatools.edit', $row->id)); ?>" data-bs-toggle="tooltip" data-bs-original-title="Tambah Diagnosa Pasien" class="btn btn-success">
                                <i class="fas fa-stethoscope text-white"></i>
                            </a>
                        </td>
                        <td><?php echo e($row->nomorantrian); ?></td>
                        <td><?php echo e($row->pasien == '' ? 'Belum ada kode' : $row->pasien->kodepasien); ?></td>
                        <td><?php echo e($row->pasien->nama); ?></td>
                        <td><?php echo e($row->pasien->lahir->format('d/M/Y')); ?></td>
                        <td><?php echo e($row->pasien->lahir->age); ?> Tahun</td>
                        <td><?php echo e($row->layanan); ?></td>
                        <td><?php echo e($row->keluhan); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    lengthMenu: [
                        [50, 100, 1000, -1],
                        ['50', '100', '1000', 'All']
                    ],
                    buttons: [{
                            extend: 'excel',
                            text: 'Excel',
                            messageTop: 'Data Antrian Harian per Tanggal '+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'
                            
                        },
                        {
                            extend: 'copy',
                            text: 'Copy Isi',
                            messageTop: 'Data Antrian Harian per Tanggal '+'<?php echo e(\Carbon\Carbon::now()->format("d-M(m)-Y")); ?>'
                            
                        },
                    ],
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-99\resources\views/diagnosa.blade.php ENDPATH**/ ?>