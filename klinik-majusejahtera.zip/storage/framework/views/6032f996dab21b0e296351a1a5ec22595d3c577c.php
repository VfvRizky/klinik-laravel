
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <div class="container">
        <h1>Data Antrian Pasien Harian</h1>
        <br>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tools</th>
                        <th>No Antrian</th>
                        <th>Jam Daftar</th>
                        <th>Nama</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Jenis Layanan</th>
                        <th>Keluhan</th>
                        <th>Dokter</th>

                        <th>Alamat</th>
                        <th>NIK</th>
                        <th>Nomer Telepon</th>
                        <th>Agama</th>
                        <th>Pendidikan</th>
                        <th>Pekerjaan</th>                       
                    </tr>
                </thead>
                <tbody>
                    
                    <?php
                        $count = 0;
                    ?>
                    <?php $__currentLoopData = $datarekam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($count = $count + 1); ?></td>
                            <td><a href="<?php echo e(route('rekam.edit', $row->id)); ?>" data-bs-toggle="tooltip" data-bs-original-title="Lihat Pasien">
                                <i class="fas fa-book text-success"></i>
                            </a>
                            <form action="<?php echo e(route('rekam.destroy', $row->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="badge bg-danger"
                                    onClick="return confirm('Yakin ingin hapus data?')">hapus</button>
                            </form>
                            </td>
                            <td><?php echo e($row->nomorantrian); ?></td>
                            <td><?php echo e($row->pasien->created_at->format('H:i:s -- d/m/Y')); ?></td>   
                            <td><?php echo e($row->pasien->nama); ?></td>
                            <td><?php echo e($row->pasien->lahir->format('d/M/Y')); ?></td>
                            <td><?php echo e($row->pasien->kelamin); ?></td>
                            <td><?php echo e($row->layanan); ?></td>
                            <td><?php echo e($row->keluhan); ?></td>
                            <td><?php echo e($row->dokter->nama); ?></td>
                            <td><?php echo e($row->pasien->alamat); ?></td>
                            <td><?php echo e($row->pasien->nik); ?></td>
                            <td><?php echo e($row->pasien->telepon); ?></td>
                            <td><?php echo e($row->pasien->agama); ?></td>
                            <td><?php echo e($row->pasien->pendidikan); ?></td>
                            <td><?php echo e($row->pasien->pekerjaan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                    
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [11, "asc"]
                    ],
                    lengthMenu: [
                        [5, 10, 25, 50, 100, 1000, -1],
                        ['5', '10', '25', '50', '100', '1000', 'All']
                    ],
                    // buttons: [{
                    //         extend: 'csv',
                    //         text: 'Export',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'pdf',
                    //         text: 'Pdf',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'print',
                    //         text: 'Print',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },

                    // ],
                    language: {
                        "searchPlaceholder": "Cari nama pasien",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-laravel88\resources\views/antrian-pasien-admin.blade.php ENDPATH**/ ?>