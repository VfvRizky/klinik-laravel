<title>Jenis - Obat</title>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Pilihan Jenis Obat</h1>
        <br>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <a href="/jenis-obat-create" type="button" class="btn btn-success">
            <i class="fas fa-plus text-white"></i> <i class="fas fa-database text-white"></i>  Tambah Jenis Obat</a>
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Jenis</th>
                        <th>Tools</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($count = $count + 1); ?> </td>
                            <td> <?php echo e($p->jenisobat); ?></td>

                            <td class="text-sm">
                                <a href="<?php echo e(route('jenis.edit', $p->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip"
                                    data-bs-original-title="Edit Pasien">
                                    <i class="fas fa-pen text-white"></i>
                                </a>

                                <form action="<?php echo e(route('jenis.destroy', $p->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onClick="return confirm('Yakin ingin hapus data?')">
                                        <i class="fas fa-trash"></i></button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    
                    lengthMenu: [
                        [10, 25, 100, -1],
                        ['10', '25', '100', 'All']
                    ],
                    language: {
                        "searchPlaceholder": "Cari Jenis obat",
                        "zeroRecords": "Tidak ditemukan Jenis Obat yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-majusejahtera\resources\views/obat-jenis.blade.php ENDPATH**/ ?>