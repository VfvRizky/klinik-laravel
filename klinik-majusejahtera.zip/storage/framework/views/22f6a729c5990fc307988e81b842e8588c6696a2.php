
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Dokter</h1>
        <br>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <a href="/dokter/create" type="button" class="btn btn-success">Tambah Dokter</a>
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Spesialis</th>
                        <th>Nomer Telepon</th>
                        <th>Jadwal Praktek</th>
                        <th>Tools</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datadokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->iteration); ?> </td>
                            <td> <?php echo e($d->nama); ?> </td>
                            <td> <?php echo e($d->alamat); ?> </td>
                            <td> <?php echo e($d->poli->name ?? "Poli kosong"); ?> </td>
                            <td> <?php echo e($d->telepon); ?> </td>
                            <td> <?php echo e($d->jadwal->jadwalpraktek ?? "jadwal kosong"); ?> </td>

                            </-------------------------------------------------------- edit
                                -----------------------------------------------------------------------------------* />
                            <td class="text-sm">
                                <a href="<?php echo e(route('dokter.edit', $d->id)); ?>" class="mx-3" data-bs-toggle="tooltip"
                                    data-bs-original-title="Edit Dokter">
                                    <i class="fas fa-pen text-warning"></i>
                                </a>

                                

                                </-------------------------------------------------------- hapus
                                    -----------------------------------------------------------------------------------* />
                                <form action="<?php echo e(route('dokter.destroy', $d->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="badge bg-danger"
                                        onClick="return confirm('Yakin ingin hapus data?')">delete</button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [11, "asc"]
                    ],
                    lengthMenu: [
                        [5, 10, 25, 50, 100, 1000, -1],
                        ['5', '10', '25', '50', '100', '1000', 'All']
                    ],
                    buttons: [{
                            extend: 'csv',
                            text: 'Export',
                            exportOptions: {
                                modifier: {
                                    page: 'all',
                                    search: 'none'
                                },
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                            }
                        },
                        {
                            extend: 'pdf',
                            text: 'Pdf',
                            exportOptions: {
                                modifier: {
                                    page: 'all',
                                    search: 'none'
                                },
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                            }
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            exportOptions: {
                                modifier: {
                                    page: 'all'
                                },
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                            }
                        },

                    ],
                    language: {
                        "searchPlaceholder": "Cari nama dokter",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-laravel88\resources\views/dokter.blade.php ENDPATH**/ ?>