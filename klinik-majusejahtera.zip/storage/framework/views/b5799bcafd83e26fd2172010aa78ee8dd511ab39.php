<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
    </script>
    <title>Dashboard|Rekam</title>
</head>

<body>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <h1>Edit Rekam</h1>
        <br>
        <form action="/updaterekamadmin" method="POST">
            <?php echo csrf_field(); ?>
        
        </--------------------------------------------------------kodepasien-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Kode Pasien</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Kodepasien" value="<?php echo e($rekam->pasien->kodepasien); ?>"
                    readonly>
            </div>
        </div>

        </--------------------------------------------------------Nama-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Nama" placeholder="Nama" required="required"
                    value="<?php echo e($rekam->pasien->nama); ?>" oninvalid="this.setCustomValidity('Nama tidak boleh kosong')"
                    oninput="setCustomValidity('')" readonly>
            </div>
        </div>

        <input type="hidden" name="idrekam" value="<?php echo e($rekam->id); ?>"> 
        <input type="hidden" name="idpasien" value="<?php echo e($id_pasien); ?>"> 

        </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Lahir</label>
            <div class="col-sm-5">
                <input type="text" class="form-control <?php $__errorArgs = ['Lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Lahir"
                    placeholder="Lahir" value="<?php echo e(date("d/m/Y", strtotime($rekam->pasien->lahir))); ?>" readonly>
                <?php $__errorArgs = ['Lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        "tanggal lahir masih kosong
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!--------------------------------------------------------Layanan----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Jenis layanan</label>
            <div class="col-sm-5">
                <select name="layanan" id="">
                    <?php if($rekam->layanan == 'Umum'): ?>
                        <option value="-">Pilih layanan..</option>
                        <option value="Umum" selected><?php echo e($rekam->layanan); ?></option>
                        <option value="Asuransi"><?php echo e('Asuransi'); ?></option>
                    <?php elseif($rekam->layanan == 'Asuransi'): ?>
                        <option value="-">Pilih layanan..</option>
                        <option value="Umum"><?php echo e('Umum'); ?></option>
                        <option value="Asuransi" selected><?php echo e($rekam->layanan); ?></option>
                    <?php else: ?>
                        <option value="-">Pilih layanan..</option>
                        <option value="Umum"><?php echo e('Umum'); ?></option>
                        <option value="Asuransi"><?php echo e('Asuransi'); ?></option>
                    <?php endif; ?>
                </select>
            </div>
        </div>

        <!--------------------------------------------------------keluhan pasien----------------------------------------------------------------------------------- -->
        <div class="form-group row mt-2">
            <label class="col-sm-2 col-form-label">Keluhan</label>
            <div class="col-sm-5">
                
                <textarea type="text" name="keluhan" class="form-control" cols="30" rows="5"
                    placeholder="Jelaskan sakit anda, dan sudah berapa lama?"><?php echo e($rekam->keluhan); ?></textarea>
            </div>
        </div>

        <!--------------------------------------------------------dokter pemriksa----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Dokter</label>
            <div class="col-sm-5">
                <select name="dokter" id="">
                    <option value="-">Pilih dokter..</option>
                    <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->id); ?>" <?php echo e($rekam->dokter->id == $row->id ? 'selected' : ''); ?>><?php echo e($row->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

           <!--------------------------------------------------------DIAGNOSA----------------------------------------------------------------------------------- -->
           <div class="form-group row">
            <label class="col-sm-2 col-form-label">Diagnosa</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="diagnosa" placeholder="Diagnosa.."
                    required="required" value="<?php echo e($rekam->diagnosa); ?>"
                    oninvalid="this.setCustomValidity('Diagnosa tidak boleh kosong')"
                    oninput="setCustomValidity('')">
            </div>
        </div>

        <!--------------------------------------------------------Obat----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Obat</label>
            <div class="col-sm-5">
                <select name="obat" id="" class="form-control">
                    <option value="-">Pilih obat..</option>
                    <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o->id); ?>" <?php echo e($rekam->obat->id == $o->id ? 'selected' : ''); ?>> 
                            <?php echo e($o->nama . ' (Sisa stok: ' . $o->stok . ')'); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <!--------------------------------------------------------banyaknya Obat----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Jumlah Obat</label>
            <div class="col-sm-5">
                <input type="number" class="form-control" name="jumlahobat"
                    placeholder="Jumlah obat" required="required" value="<?php echo e($rekam->jumlahobat); ?>"
                    oninvalid="this.setCustomValidity('Jumlah Obat tidak boleh kosong')"
                    oninput="setCustomValidity('')">
            </div>
        </div>

        <!--------------------------------------------------------keterangan----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Keterangan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="keterangan"
                    placeholder="Keterangan.." required="required" value="<?php echo e($rekam->keterangan); ?>"
                    oninvalid="this.setCustomValidity('Keterangan tidak boleh kosong')"
                    oninput="setCustomValidity('')">
            </div>
        </div>


        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(route('pasien.edit', $id_pasien)); ?>" class="btn btn-warning">Kembali</a>
            </div>
        </div>
        </form>
    </div>

    <script>
        function setInputFilter(textbox, inputFilter, errMsg) {
            ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(
                function(event) {
                    textbox.addEventListener(event, function(e) {
                        if (inputFilter(this.value)) {
                            // Accepted value
                            if (["keydown", "mousedown", "focusout"].indexOf(e.type) >= 0) {
                                this.classList.remove("input-error");
                                this.setCustomValidity("");
                            }
                            this.oldValue = this.value;
                            this.oldSelectionStart = this.selectionStart;
                            this.oldSelectionEnd = this.selectionEnd;
                        } else if (this.hasOwnProperty("oldValue")) {
                            // Rejected value - restore the previous one
                            this.classList.add("input-error");
                            this.setCustomValidity(errMsg);
                            this.reportValidity();
                            this.value = this.oldValue;
                            this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
                        } else {
                            // Rejected value - nothing to restore
                            this.value = "";
                        }
                    });
                });
        }

        setInputFilter(document.getElementById("nonik"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
        setInputFilter(document.getElementById("notelp"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\klinik-laravel88\resources\views/edit-rekam-admin-form.blade.php ENDPATH**/ ?>