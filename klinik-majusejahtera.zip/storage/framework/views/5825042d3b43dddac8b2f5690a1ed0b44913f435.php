<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset ('css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <title>Dashboard|Edit Jadwal</title>
</head>
<body>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  <?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="alert alert-danger" role="alert">
    <?php echo e($item); ?>

  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <?php endif; ?>  
    <div class="container">
      <h1>Perubahan Jadwal</h1>
        <br>
    <form action="<?php echo e(route('jadwal.update', $jadwal->id)); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      

    </--------------------------------------------------------Jadwal-----------------------------------------------------------------------------------*/>
    <div class="form-group row">
      <label class="col-sm-2 col-form-label">Jadwal Lama</label>
      <div class="col-sm-5" >
        <input type="text" class="form-control" name ="Jadwal" placeholder="Jadwal" value="<?php echo e($jadwal->jadwalpraktek); ?>" readonly>
      </div>
    </div>

    </--------------------------------------------------------Jadwal-----------------------------------------------------------------------------------*/>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Jadwal Baru</label>
          <div class="col-sm-5" >
            <input type="text" class="form-control" name ="Jadwal" placeholder="Jadwal" value="<?php echo e($jadwal->jadwalpraktek); ?>">
          </div>
        </div>
        


        <div class="form-group row">
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Ubah</button>
            <a href="/jadwal" class="btn btn-warning">Batal</a>
          </div>
        </div>
      </form>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\klinik-laravel\resources\views/jadwal-form-edit.blade.php ENDPATH**/ ?>