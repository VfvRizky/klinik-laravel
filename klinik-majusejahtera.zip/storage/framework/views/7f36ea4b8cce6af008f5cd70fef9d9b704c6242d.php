<title>Akun Admin</title>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Akun</h1>
        <br>

        <a href="/tambah-akun" type="button" class="btn btn-success">
            <i class="fas fa-plus text-white"></i> <i class="fas fa-user text-white"></i> Tambah Akun</a>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Admin</th>
                        <th>Superadmin</th>
                        <th>Tools</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count = $count + 1); ?></td>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->email); ?></td>
                        <td><?php echo e($u->is_admin == 1 ? 'Yes' : 'No'); ?></td>
                        <td><?php echo e($u->is_superadmin == 1 ? 'Yes' : 'No'); ?></td>
                        <td>  
                            <a href="<?php echo e(route('user.edit', $u->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip"
                                data-bs-original-title="Edit Obat">
                                <i class="fas fa-pen text-white"></i>
                            </a>

                        </-------------------------------------------------------- hapus
                            -----------------------------------------------------------------------------------* />
                            <form action="<?php echo e(route('user.destroy', $u->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger"
                                onClick="return confirm('Yakin ingin hapus data?')"><i class="fas fa-trash"></i></button>

                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    lengthMenu: [
                        [10, 100, -1],
                        ['10', '100', 'All']
                    ],
                    
                    language: {
                        "searchPlaceholder": "Cari nama Akun",
                        "zeroRecords": "Tidak ditemukan data Akun yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-majusejahtera\resources\views/user.blade.php ENDPATH**/ ?>