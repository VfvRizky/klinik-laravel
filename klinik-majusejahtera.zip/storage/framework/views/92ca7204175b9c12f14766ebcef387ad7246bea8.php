
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Data Stok Obat</h1>
        <br>

        <a href="/obat-form" type="button" class="btn btn-success">Tambah Obat</a>

        </-------------------------------------------------------- Tabel
            -----------------------------------------------------------------------------------* />
        <br />
        <div class="table-responsive">
            <table class="table table-flush" id="products-list">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Tools</th>
                        <th>Kode Obat</th>
                        <th>Stok</th>
                        <th>Jenis</th>
                        <th>Status</th>
                        <th>Nama</th>
                        <th>Dosis</th>
                        <th>Harga</th>
                        <th>Tanggal Buat</th>
                        <th>Tanggal Expired</th>
                        <th>Photo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> 1 </td>
                            </-------------------------------------------------------- edit
                                -----------------------------------------------------------------------------------* />
                            <td class="text-sm">
                                <a href="<?php echo e(route('obat.edit', $p->id)); ?>" class="mx-3" data-bs-toggle="tooltip"
                                    data-bs-original-title="Edit Pasien">
                                    <i class="fas fa-pen text-warning"></i>
                                </a>

                                <a href="/edit-stok/<?php echo e($p->id); ?>" class="btn btn-warning" data-bs-toggle="tooltip"
                                    data-bs-original-title="Edit Pasien">
                                    Edit Stok
                                </a>

                                </-------------------------------------------------------- hapus
                                    -----------------------------------------------------------------------------------* />
                                <form action="<?php echo e(route('obat.destroy', $p->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="badge bg-danger"
                                        onClick="return confirm('Yakin ingin hapus data?')">hapus</button>

                                </form>
                            </td>
                            <td> <?php echo e($p->kodeobat); ?></td>
                            <td> <?php echo e($p->stok); ?></td>
                            <td><?php echo e($p->jenis->jenisobat); ?></td>
                            <td>
                                <?php
                                    $expired = date('d/m/Y', strtotime($p->expired));
                                    $today = date('d/m/Y');
                                    
                                    if ($today < $expired) {
                                        echo 'Bagus';
                                    } else {
                                        echo 'Expired';
                                    }
                                ?>
                            </td>
                            <td> <?php echo e($p->nama); ?></td>
                            <td> <?php echo e($p->dosis); ?></td>
                            <td> <?php echo e("Rp " . number_format($p->harga,2,',','.')); ?></td>
                            <td> <?php echo e($p->created_at); ?></td>
                            <td> <?php echo e($p->expired); ?></td>
                            <td> <img src="/image/<?php echo e($p->photo); ?>" alt="" width="300%"></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#products-list').DataTable({
                    dom: 'lBfrtip',
                    orderable: [
                        [11, "asc"]
                    ],
                    lengthMenu: [
                        [5, 10, 25, 50, 100, 1000, -1],
                        ['5', '10', '25', '50', '100', '1000', 'All']
                    ],
                    // buttons: [{
                    //         extend: 'csv',
                    //         text: 'Export',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'pdf',
                    //         text: 'Pdf',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all',
                    //                 search: 'none'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },
                    //     {
                    //         extend: 'print',
                    //         text: 'Print',
                    //         exportOptions: {
                    //             modifier: {
                    //                 page: 'all'
                    //             },
                    //             columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                    //         }
                    //     },

                    // ],
                    language: {
                        "searchPlaceholder": "Cari nama obat",
                        "zeroRecords": "Tidak ditemukan data yang sesuai",
                        "emptyTable": "Tidak terdapat data di tabel"
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\klinik-laravel\resources\views/obat-total-stok.blade.php ENDPATH**/ ?>