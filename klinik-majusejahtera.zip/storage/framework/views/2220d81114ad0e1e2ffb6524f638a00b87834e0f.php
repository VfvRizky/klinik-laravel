<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
    </script>
    <title>Dashboard|Form Diagnosa</title>
</head>

<body>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($item); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="container">
        <h1>Diagnosa Pasien</h1>
        <br>
        <form action="<?php echo e(route('diagnosatools.update', $diagnosa->id)); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
      
        </--------------------------------------------------------kodepasien-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Kode Pasien (lama muncul, baru kosong)</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Kodepasien" value="<?php echo e($diagnosa->pasien->kodepasien); ?>" readonly>
            </div>
        </div>
        
    <!--------------------------------------------------------kodepasien regis (bagi yang baru)------------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Kode Regis Pasien</label>
            <div class="col-sm-5">
                <input type="number" class="form-control" name="Kodepasien-Regis" placeholder="Masukkan jika pasien baru"
                required="required" value="<?php echo e(old('Kodepasien-Regis')); ?>"> 
            </div>
        </div>

        </--------------------------------------------------------Nama-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Nama" placeholder="Nama" required="required"
                    value="<?php echo e($diagnosa->pasien->nama); ?>" oninvalid="this.setCustomValidity('Nama tidak boleh kosong')"
                    oninput="setCustomValidity('')" readonly>
            </div>
        </div>

    </--------------------------------------------------------NIK-----------------------------------------------------------------------------------* />
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">NIK (Kartu Keluarga)</label>
        <div class="col-sm-5">
            <input type="text" class="form-control" name="NIK" value="<?php echo e($diagnosa->pasien->nik); ?>" readonly>
        </div>
    </div>

        </--------------------------------------------------------Lahir-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Lahir</label>
            <div class="col-sm-5">
                <input type="date" class="form-control" name ="Lahir" value="<?php echo e($diagnosa->pasien->lahir->format('Y-m-d')); ?>" readonly>
            </div>
        </div>





    
    <!--------------------------------------------------------Layanan----------------------------------------------------------------------------------- -->
    <div class="form-group row">
            <label class="col-sm-2 col-form-label">Jenis layanan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Nama"
                    required="required" value="<?php echo e($diagnosa->layanan); ?>"
                    oninvalid="this.setCustomValidity('layanan tidak boleh kosong')" oninput="setCustomValidity('')"
                    readonly>
            </div>
        </div>

        <!--------------------------------------------------------keluhan pasien----------------------------------------------------------------------------------- -->
        <div class="form-group row mt-2">
            <label class="col-sm-2 col-form-label">Keluhan</label>
            <div class="col-sm-5">
                
                <textarea readonly type="text" name="RekamMedis" class="form-control" cols="30" rows="5"
                    placeholder="Jelaskan sakit anda, dan sudah berapa lama?"><?php echo e($diagnosa->keluhan); ?></textarea>
            </div>
        </div>

        <!--------------------------------------------------------dokter pemriksa----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Dokter</label>
            <div class="col-sm-5">
                <input type="text" value="<?php echo e($diagnosa->dokter->nama); ?>" readonly class="form-control">
            </div>
        </div>

    </--------------------------------------------------------umur-----------------------------------------------------------------------------------* />
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Umur</label>
        <div class="col-sm-5">
           <h1> <?php echo e($diagnosa->pasien->lahir->age); ?> Tahun </h1>
        </div>
    </div>

        <!--------------------------------------------------------DIAGNOSA----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Diagnosa</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="diagnosa" placeholder="Diagnosa.."
                    required="required" value="<?php echo e(old('diagnosa')); ?>"
                    oninvalid="this.setCustomValidity('Diagnosa tidak boleh kosong')" oninput="setCustomValidity('')">
            </div>
        </div>
        
        <!--------------------------------------------------------Obat----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Obat</label>
            <div class="col-sm-5">
                <select name="obat" id="" class="form-control">
                    <option value="-">Pilih obat..</option>
                    <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($o->id); ?>"><?php echo e($o->nama. " (Sisa stok: ".  $o->stok .")"); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <!--------------------------------------------------------banyaknya Obat----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Jumlah Obat</label>
            <div class="col-sm-5">
                <input type="number" class="form-control" name="jumlahobat"
                    placeholder="Jumlah obat"
                    required="required" value="<?php echo e(old('Nama')); ?>"
                    oninvalid="this.setCustomValidity('Jumlah Obat tidak boleh kosong')"
                    oninput="setCustomValidity('')">
            </div>
        </div>

        <!--------------------------------------------------------keterangan----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Keterangan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="keterangan" placeholder="Keterangan.."
                    required="required" value="<?php echo e(old('keterangan')); ?>"
                    oninvalid="this.setCustomValidity('Keterangan tidak boleh kosong')"
                    oninput="setCustomValidity('')">
                </div>
            </div>

        </--------------------------------------------------------pasien lama/baru-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-form-label col-sm-2 pt-0">Pasien Lama/Baru</label>
            <div class="col-sm-5">
                <select name="Pasien-lamabaru" value="<?php echo e(old('Pasien-lamabaru')); ?>" class="form-control <?php $__errorArgs = ['Pasien-lamabaru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    
                    <option selected value="">pilih...</option>
                    <option value="Lama" <?php echo e(old('Pasien-lamabaru') != 'Lama' ?: 'selected'); ?>>Lama</option>
                    <option value="Baru" <?php echo e(old('Pasien-lamabaru') != 'Baru' ?: 'selected'); ?>>Baru</option>
                </select>
                <?php $__errorArgs = ['Pasien-lamabaru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        "pilih lama / baru
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    
    </--------------------------------------------------------jalan / inap-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-form-label col-sm-2 pt-0">Ruang</label>
            <div class="col-sm-5">
                <select name="Ruang" value="<?php echo e(old('Ruang')); ?>" class="form-control <?php $__errorArgs = ['Ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    
                    <option selected value="">pilih...</option>
                    <option value="R.Jalan" <?php echo e(old('Ruang') != 'R.Jalan' ?: 'selected'); ?>>R. Jalan</option>
                    <option value="R.Inap" <?php echo e(old('Ruang') != 'R.Inap' ?: 'selected'); ?>>R. Inap</option>
                </select>
                <?php $__errorArgs = ['Ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        "pilih jalan / inap
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <h5>==== khusus penyakit tertentu ====</h5>

    </--------------------------------------------------------Golongan darah-----------------------------------------------------------------------------------* />
    <div class="form-group row">
        <label class="col-form-label col-sm-2 pt-0">Golongan Darah</label>
        <div class="col-sm-5">
            <select name="Darah" value="<?php echo e(old('Darah')); ?>" class="form-control">

                <option selected value="-">pilih...</option>
                <option value="A+" <?php echo e(old('Darah') != 'A+' ?: 'selected'); ?>>A+</option>
                <option value="B+" <?php echo e(old('Darah') != 'B+' ?: 'selected'); ?>>B+</option>
                <option value="AB+" <?php echo e(old('Darah') != 'AB+' ?: 'selected'); ?>>AB+</option>
                <option value="O+" <?php echo e(old('Darah') != 'O+' ?: 'selected'); ?>>O+</option>
                <option value="A-" <?php echo e(old('Darah') != 'A-' ?: 'selected'); ?>>A-</option>
                <option value="B-" <?php echo e(old('Darah') != 'B-' ?: 'selected'); ?>>B-</option>
                <option value="AB-" <?php echo e(old('Darah') != 'AB-' ?: 'selected'); ?>>AB-</option>
                <option value="O-" <?php echo e(old('Darah') != 'O-' ?: 'selected'); ?>>O-</option>
            </select>
        </div>
    </div>

        <!--------------------------------------------------------Tinggi Badan----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Tinggi Badan</label>
            <div class="col-sm-5">
                <input type="number" class="form-control" name="Tinggi" placeholder="Tinggi Badan (Cm)"
                    required="required" value="<?php echo e(old('Tinggi')); ?>">
                </div>
            </div>
        
            <!--------------------------------------------------------Berat Badan----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Berat Badan</label>
            <div class="col-sm-5">
                <input type="number" class="form-control" name="Berat" placeholder="Berat Badan (Kg)"
                    required="required" value="<?php echo e(old('Berat')); ?>">
                </div>
            </div>
            
            <!--------------------------------------------------------lingkar Pinggang----------------------------------------------------------------------------------- -->
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Lingkar Badan</label>
            <div class="col-sm-5">
                <input type="number" class="form-control" name="LingkarBadan" placeholder="Lingkar Badan (Cm)"
                    required="required" value="<?php echo e(old('LingkarBadan')); ?>">
                </div>
            </div>


        </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Alamat" value="<?php echo e($diagnosa->pasien->alamat); ?>" readonly>
            </div>
        </div>
        
        </--------------------------------------------------------No Handphone-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Nomer Handphone</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Telepon" value="<?php echo e($diagnosa->pasien->telepon); ?>" readonly>
            </div>
        </div>
        
        </--------------------------------------------------------Pendidikan-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Pendidikan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Pendidikan" value="<?php echo e($diagnosa->pasien->pendidikan); ?>" readonly>
            </div>
        </div>
        
        </--------------------------------------------------------Pekerjaan-----------------------------------------------------------------------------------* />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Pekerjaan</label>
            <div class="col-sm-5">
                <input type="text" class="form-control" name="Pekerjaan" value="<?php echo e($diagnosa->pasien->pekerjaan); ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">DIAGNOSA</button>
                <a href="/diagnosa" class="btn btn-warning">Kembali</a>
            </div>
        </div>
        </form>
    </div>

    <script>
        function setInputFilter(textbox, inputFilter, errMsg) {
            ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(
                function(event) {
                    textbox.addEventListener(event, function(e) {
                        if (inputFilter(this.value)) {
                            // Accepted value
                            if (["keydown", "mousedown", "focusout"].indexOf(e.type) >= 0) {
                                this.classList.remove("input-error");
                                this.setCustomValidity("");
                            }
                            this.oldValue = this.value;
                            this.oldSelectionStart = this.selectionStart;
                            this.oldSelectionEnd = this.selectionEnd;
                        } else if (this.hasOwnProperty("oldValue")) {
                            // Rejected value - restore the previous one
                            this.classList.add("input-error");
                            this.setCustomValidity(errMsg);
                            this.reportValidity();
                            this.value = this.oldValue;
                            this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
                        } else {
                            // Rejected value - nothing to restore
                            this.value = "";
                        }
                    });
                });
        }

        setInputFilter(document.getElementById("nonik"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
        setInputFilter(document.getElementById("notelp"), function(value) {
            return /^-?\d*$/.test(value);
        }, "Isi dengan Angka");
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\klinik-laravel88\resources\views/diagnosa-form.blade.php ENDPATH**/ ?>