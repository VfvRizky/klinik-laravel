<title>Pegawai : <?php echo e($pegawai->nama); ?></title>
    <?php echo $__env->make('partials.navdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e($item); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php endif; ?>
    <div class="container">
        <h1>Ubah Data Pegawai</h1>
        <br>
        <form action="<?php echo e(route('pegawai.update', $pegawai->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
     
        </--------------------------------------------------------Kode Pegawai-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Kode Pegawai</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="KodePegawai" placeholder="KodePegawai" required
                        value="<?php echo e($pegawai->kodepegawai); ?>" oninvalid="this.setCustomValidity('Isi - jika tidak tau')" oninput="setCustomValidity('')">
                </div>
            </div>
            </--------------------------------------------------------Nama-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Nama" placeholder="Nama" required="required"
                        value="<?php echo e($pegawai->nama); ?>" oninvalid="this.setCustomValidity('Nama tidak boleh kosong')" oninput="setCustomValidity('')">
                </div>
            </div>
            </--------------------------------------------------------Alamat-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" name="Alamat" placeholder="Alamat"
                        value="<?php echo e($pegawai->alamat); ?>">
                </div>
            </div>


        </--------------------------------------------------------Kelamin-----------------------------------------------------------------------------------*/>
    
        <div class="form-group row">
            <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
            <div class="col-sm-5">
                <select name="Kelamin" class="form-control" value="<?php echo e($pegawai->kelamin); ?>"
                    required oninvalid="this.setCustomValidity('pilih salah satu...')"
                                    oninput="setCustomValidity('')">
                    <option selected value ="">pilih...</option>
                    <option value="laki-laki" <?php echo e($pegawai->kelamin == 'laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="perempuan" <?php echo e($pegawai->kelamin == 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                  </select>
            </div>
        </div>

            </--------------------------------------------------------Telepon-----------------------------------------------------------------------------------* />
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Telepon</label>
                <div class="col-sm-3">
                    <input type="number" class="form-control" id="notelp" name="Telepon"
                    placeholder="Nomer Telepon (aktif)" value="<?php echo e($pegawai->telepon); ?>"
                    required oninvalid="this.setCustomValidity('isi 0 jika tidak tau')"
                                    oninput="setCustomValidity('')">
                </div>
            </div>


        </--------------------------------------------------------Agama-----------------------------------------------------------------------------------* />

        <div class="form group row">
            <label class="col-form-label col-sm-2 pt-0">Agama</label>
            <div class="col-sm-3">
                <select name="Agama" class="form-control" required
                                oninvalid="this.setCustomValidity('agama tidak boleh kosong')"
                                oninput="setCustomValidity('')">
                                <option selected value="">Pilih agama..</option>
                                <option value="islam" <?php echo e($pegawai->agama == 'islam' ? 'selected' : ''); ?>>Islam</option>
                                <option value="protestan" <?php echo e($pegawai->agama == 'protestan' ? 'selected' : ''); ?>>Kristen
                                    Protestan
                                </option>
                                <option value="katolik" <?php echo e($pegawai->agama == 'katolik' ? 'selected' : ''); ?>>Kristen Katolik
                                </option>
                                <option value="hindu" <?php echo e($pegawai->agama == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
                                <option value="buddha" <?php echo e($pegawai->agama == 'buddha' ? 'selected' : ''); ?>>Buddha</option>
                                <option value="konghucu" <?php echo e($pegawai->agama == 'konghucu' ? 'selected' : ''); ?>>Konghucu
                                </option>
                            </select>
                <?php $__errorArgs = ['Agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        "agama masih kosong
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <br>
    </--------------------------------------------------------Jabatan-----------------------------------------------------------------------------------* />

    <div class="form group row">
        <label class="col-form-label col-sm-2 pt-0">Jabatan</label>
        <div class="col-sm-3">

            <select name="Jabatan" class="form-control" required
                                oninvalid="this.setCustomValidity('pilih - jika tidak tau')"
                                oninput="setCustomValidity('')">
                                <option selected value="">pilih...</option>
                                <option value="-" <?php echo e($pegawai->jabatan == '-' ? 'selected' : ''); ?>>-</option>
                                <option value="Perawat" <?php echo e($pegawai->jabatan == 'Perawat' ? 'selected' : ''); ?>>Perawat</option>
                                <option value="Apoteker" <?php echo e($pegawai->jabatan == 'Apoteker' ? 'selected' : ''); ?>>Apoteker</option>
                                <option value="Admin" <?php echo e($pegawai->jabatan == 'Admin' ? 'selected' : ''); ?>>Admin</option>
                                <option value="Bendahara" <?php echo e($pegawai->jabatan == 'Bendahara' ? 'selected' : ''); ?>>Bendahara</option>
                                <option value="Security" <?php echo e($pegawai->jabatan == 'Security' ? 'selected' : ''); ?>>Security</option>
                            </select>
           
        </div>
    </div>
            <br>
            

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="/pegawai" class="btn btn-warning">Kembali</a>
                </div>
            </div>
        </form>
    </div>
<?php /**PATH C:\xampp\htdocs\klinik-99\resources\views/pegawai-form-edit.blade.php ENDPATH**/ ?>